package com.example.android.bluetoothlegatt;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TimePicker;
import android.widget.Toast;

/**
 * @author Andrew Deschenes
 * Used to get the time to be sent to the alarm clock. Uses a TimePicker and then sends
 * the chosen time over BluetoothLE
 */
public class SetTimeActivity extends Activity {

    private Toast toast;
    private int duration = Toast.LENGTH_SHORT;
    private String message = "Time successfully set";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_time);
    }

    public void getTime (View v){

        TimePicker t = (TimePicker) findViewById(R.id.timePicker);

        //Send time via BluetoothLE
        DeviceControlActivity.sendTime(t.getHour(), t.getMinute());

        toast.makeText(getApplicationContext(), message, duration).show();

        //Finish activity
        this.finish();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home:
                this.finish(); //finish activity when back is clicked (preserves connection)
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
