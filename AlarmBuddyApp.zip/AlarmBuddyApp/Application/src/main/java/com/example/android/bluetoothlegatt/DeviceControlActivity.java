/*
 * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.bluetoothlegatt;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

/**
 * @author Andrew Deschenes
 * This code has been added to and completely remodified
 * from the orginal example found in the Android Studio example programs.
 */

/**
 * For a given BLE device, this Activity provides the user interface to connect, display data,
 * and display GATT services and characteristics supported by the device.  The Activity
 * communicates with {@code BluetoothLeService}, which in turn interacts with the
 * Bluetooth LE API.
 */
public class DeviceControlActivity extends Activity{

    private final static String TAG = DeviceControlActivity.class.getSimpleName();

    public static final String EXTRAS_DEVICE_NAME = "DEVICE_NAME";
    public static final String EXTRAS_DEVICE_ADDRESS = "DEVICE_ADDRESS";

    private String mDeviceName;
    private String mDeviceAddress;
    private static BluetoothLeService mBluetoothLeService;

    private boolean mConnected = false;

    // Code to manage Service lifecycle.
    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
            if (!mBluetoothLeService.initialize()) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                finish();
            }
            // Automatically connects to the device upon successful start-up initialization.
            mBluetoothLeService.connect(mDeviceAddress);

        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBluetoothLeService = null;
        }
    };

    // Handles various events fired by the Service.
    // ACTION_GATT_CONNECTED: connected to a GATT server.
    // ACTION_GATT_DISCONNECTED: disconnected from a GATT server.
    // ACTION_GATT_SERVICES_DISCOVERED: discovered GATT services.
    // ACTION_DATA_AVAILABLE: received data from the device.  This can be a result of read
    //                        or notification operations.
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                mConnected = true;
                updateConnectionState(R.string.connected);
                invalidateOptionsMenu();
            } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action)) {
                mConnected = false;
                updateConnectionState(R.string.disconnected);
                invalidateOptionsMenu();
            } else if (BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action)) {
                displayData(intent.getStringExtra(BluetoothLeService.EXTRA_DATA));
            }
        }
    };



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.button_control);

        final Intent intent = getIntent();
        mDeviceName = intent.getStringExtra(EXTRAS_DEVICE_NAME);
        mDeviceAddress = intent.getStringExtra(EXTRAS_DEVICE_ADDRESS);

        getActionBar().setTitle(mDeviceName);
        getActionBar().setDisplayHomeAsUpEnabled(true);
        Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
        if (mBluetoothLeService != null) {
            final boolean result = mBluetoothLeService.connect(mDeviceAddress);
            Log.d(TAG, "Connect request result=" + result);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mGattUpdateReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(mServiceConnection);
        mBluetoothLeService = null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.gatt_services, menu);
        if (mConnected) {
            menu.findItem(R.id.menu_connect).setVisible(false);
            menu.findItem(R.id.menu_disconnect).setVisible(true);
        } else {
            menu.findItem(R.id.menu_connect).setVisible(true);
            menu.findItem(R.id.menu_disconnect).setVisible(false);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.menu_connect:
                mBluetoothLeService.connect(mDeviceAddress);
                return true;
            case R.id.menu_disconnect:
                mBluetoothLeService.disconnect();
                return true;
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void updateConnectionState(final int resourceId) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                //mConnectionState.setText(resourceId);
            }
        });
    }

    /**
     * Creates an alert to display the data (used for temperature)
     * @param data
     */
    private void displayData(String data) {

        String s;

        if (data != null) {
            s = "The current temperature is: " + data + "°C";
        }else{
            s = "Error reading temperature! Please assure the temperature sensor is wired correctly";
        }

        AlertDialog alertDialog = new AlertDialog.Builder(DeviceControlActivity.this).create();
        alertDialog.setTitle("Temperature Update");
        alertDialog.setMessage(s);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        return intentFilter;
    }

    /**
     * Reads the temperature from the alarm clock
     * @param v
     */
    public void tempRead(View v){

        if(mBluetoothLeService != null) {
            mBluetoothLeService.readCustomCharacteristic(1);
        }

    }

    /**
     * Used to test the BluetoothLE connection with the alarm clock
     * @param v
     */
    public void testConnection(View v){

        if(mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(0x11,0);
        }

        sleep(400);

        if(mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(0x00,0);
        }

    }

    /**
     * Switches to the SetTimeActivity
     * @param v
     */
    public void setTimeActivity(View v){
        Intent i = new Intent(this, SetTimeActivity.class);
        startActivity(i);
    }
    /**
     * Switches to the SetDateActivity
     * @param v
     */
    public void setDateActivity(View v){
        Intent i = new Intent(this, SetDateActivity.class);
        startActivity(i);
    }
    /**
     * Switches to the SetAlarmActivity
     * @param v
     */
    public void setAlarmActivity(View v){
        Intent i = new Intent(this, SetAlarmActivity.class);
        startActivity(i);
    }
    /**
     * Switches to the ColorActivity
     * @param v
     */
    public void setColorActivity(View v){
        Intent i = new Intent(this, ColorActivity.class);
        startActivity(i);
    }
    /**
     * Switches to the NightMode Activity
     * @param v
     */
    public void setNightModeActivity(View v){
        Intent i = new Intent(this, NightMode.class);
        startActivity(i);
    }

    /**
     * Writes to the event characteristic (used for deciphering what data is being sent from the app)
     * @param val the value to change the event characteristic to
     */
    public static void setEvent(int val) {

        if (mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(val, 6);
        }

        sleep(200);

    }

    /**
     * Sends the updated time to the alarm clock
     * @param hour
     * @param minute
     */
    public static void sendTime(int hour, int minute){

        setEvent(0);

        if (mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(hour, 1);
        }

        sleep(200);


        if (mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(minute, 2);
        }
    }

    /**
     * Sends the colour chosen from the app to the alarm clock
     * @param r
     * @param g
     * @param b
     */
    public static void sendColor(int r, int g, int b){


        if (mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(r , 3);
        }

        sleep(200);


        if (mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(g, 4);
        }

        sleep(200);


        if (mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(b,8);
        }

    }

    /**
     * Sends the date chosen from the app to the alarm clock
     * @param day
     * @param month
     * @param year
     */
    public static void sendDate(int day, int month, int year){

        setEvent(0);

        if (mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(day, 3);
        }

        sleep(200);


        if (mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(month, 4);
        }

        sleep(200);


        if (mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(year, 5);
        }
    }

    /**
     * Sends the alarm and the days for the alarm to go off
     * @param hour
     * @param minute
     * @param day
     */
    public static void sendAlarm(int hour, int minute, int day){

        setEvent(day + 2);

        if (mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(hour, 1);
        }

        sleep(200);


        if (mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(minute, 2);
        }

        sleep(200);



    }

    /**
     * Sends the Night mode start and stop time
     * @param hour
     * @param minute
     * @param event
     */
    public static void sendNightMode(int hour, int minute, int event){

        setEvent(event);

        if (mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(hour, 1);
        }

        sleep(200);


        if (mBluetoothLeService != null) {
            mBluetoothLeService.writeCustomCharacteristic(minute, 2);
        }

        sleep(200);

    }

    private static void sleep(int time){
        try {
            Thread.sleep(time);
        }catch(Exception e){

        }
    }


}


