package com.example.android.bluetoothlegatt;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

/**
 * @author Andrew Deschenes
 * Used to set the date displayed on the alarm clock. Gets the value from a DatePicker and
 * sends it over BluetoothLE
 */
public class SetDateActivity extends Activity {

    private Toast toast;
    private int duration = Toast.LENGTH_SHORT;
    private String message = "Date successfully set";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_date);
    }

    public void getDate (View v){

        DatePicker d = (DatePicker) findViewById(R.id.datePicker);

        //Send date via BluetoothLE
        DeviceControlActivity.sendDate(d.getDayOfMonth(), d.getMonth() + 1,  d.getYear() - 2000);

        toast.makeText(getApplicationContext(), message, duration).show();

        //Finish activity
        this.finish();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home:
                this.finish(); //finish activity when back is clicked (preserves connection)
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
